sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("com.ram.travels.controller.App", {
      onInit() {
      }
  });
});